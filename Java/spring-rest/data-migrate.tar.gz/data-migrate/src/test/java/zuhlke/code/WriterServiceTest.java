package zuhlke.code;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import zuhlke.code.model.StoreOrder;
import zuhlke.code.service.WriterService;

import java.sql.Date;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest()
public class WriterServiceTest {

    @Autowired
    WriterService writerService;

    StoreOrder.StoreOrderBuilder storeOrder;

    @Before
    public void setUp() {
        storeOrder = StoreOrder.builder()
                .order_id("CA-2016-152156")
                .order_date(new Date(2016, 11, 12))
                .ship_date(new Date(2016, 11, 12))
                .quantity(2)
                .profit(41.9136)
                .product_id("FUR-BO-10001798")
                .category("Furniture")
                .customer_id("CG-12520")
                .customer_name("Claire Gute");
    }

    @After
    public void cleanUp() {
        writerService.deleteAll();
    }

    @Test
    public void add_one_good_order() {
        Assertions.assertFalse(writerService.findAll().iterator().hasNext());
        writerService.save(storeOrder.build());
        writerService.findAll().iterator().forEachRemaining(item -> Assertions.assertEquals("CA-2016-152156", item.getOrder_id()));
    }

    @Test
    public void null_SHIP_DATE() {
        null_checker(storeOrder.ship_date(null));
    }

    @Test
    public void null_ORDER_ID() {
        null_checker(storeOrder.order_id(null));
    }

    @Test
    public void null_ORDER_DATE() {
        null_checker(storeOrder.order_date(null));
    }

    @Test
    public void null_QUANTITY() {
        null_checker(storeOrder.quantity(null));
    }

    @Test
    public void null_PROFIT() {
        null_checker(storeOrder.profit(null));
    }

    @Test
    public void null_PRODUCT_ID() {
        null_checker(storeOrder.product_id(null));
    }

    @Test
    public void null_CUSTOMER_NAME() {
        null_checker(storeOrder.customer_name(null));
    }

    @Test
    public void null_CATEGORY() {
        null_checker(storeOrder.category(null));
    }

    @Test
    public void null_CUSTOMER_ID() {
        null_checker(storeOrder.customer_id(null));
    }




    private void null_checker(StoreOrder.StoreOrderBuilder storeOrder) {
        try {
            writerService.save(storeOrder.build());
        } catch (DataIntegrityViolationException e) {
            return;
        } catch (Exception e) {
            Assert.fail();
        }
        Assert.fail();
    }

}
