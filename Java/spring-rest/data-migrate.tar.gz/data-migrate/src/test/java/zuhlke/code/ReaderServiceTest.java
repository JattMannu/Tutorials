package zuhlke.code;

import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import zuhlke.code.model.StoreOrder;
import zuhlke.code.service.ReaderService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest()
public class ReaderServiceTest {

    @Autowired
    private ReaderService readerService;

    Path resourceDirectory = Paths.get("csv","testdata");

    private List<StoreOrder> getStoreOrders(Path testDataPath) {
        File testData = null;
        try {
            testData = new ClassPathResource(testDataPath.toString()).getFile();
        } catch (IOException e) {
            Assert.fail("Missing resource : " + testDataPath);
        }
        return readerService.read(testData);
    }

    @Test
    public void convert_one_good_row(){
        List<StoreOrder> read = getStoreOrders(resourceDirectory.resolve("one_row_good_data.csv"));

        Assertions.assertEquals(1 , read.size());

        StoreOrder order = read.get(0);
        Assertions.assertEquals("CA-2016-152156", order.getOrder_id());
        Assertions.assertEquals("2016-12-08",order.getOrder_date().toString());

        Assertions.assertEquals("2016-12-11",order.getShip_date().toString());
        Assertions.assertEquals("Second Class",order.getShip_mode());

        Assertions.assertEquals(2,order.getQuantity());
        Assertions.assertEquals(0.0,order.getDiscount());
        Assertions.assertEquals(41.9136,order.getProfit());

        Assertions.assertEquals("FUR-BO-10001798",order.getProduct_id());
        Assertions.assertEquals("Claire Gute",order.getCustomer_name());
        Assertions.assertEquals("Furniture",order.getCategory());

        Assertions.assertEquals("CG-12520",order.getCustomer_id());
        Assertions.assertEquals("Bush Somerset Collection Bookcase",order.getProduct_name());
    }

    @Test
    public void convert_two_good_row(){
        List<StoreOrder> read = getStoreOrders(resourceDirectory.resolve("two_row_good_data.csv"));
        Assertions.assertEquals(2, read.size());
    }

    @Test
    public void convert_one_row_with_one_empty_value(){
        List<StoreOrder> read = getStoreOrders(resourceDirectory.resolve("one_row_empty_data.csv"));

        Assertions.assertEquals(1 , read.size());

        StoreOrder order = read.get(0);

        Assertions.assertEquals("CA-2016-152156", order.getOrder_id());
        Assertions.assertNull(order.getOrder_date());

        Assertions.assertEquals("2016-12-11",order.getShip_date().toString());
        Assertions.assertEquals("Second Class",order.getShip_mode());

        Assertions.assertEquals(2,order.getQuantity());
        Assertions.assertEquals(0.0,order.getDiscount());
        Assertions.assertEquals(41.9136,order.getProfit());

        Assertions.assertEquals("FUR-BO-10001798",order.getProduct_id());
        Assertions.assertEquals("Claire Gute",order.getCustomer_name());
        Assertions.assertEquals("Furniture",order.getCategory());

        Assertions.assertEquals("CG-12520",order.getCustomer_id());
        Assertions.assertEquals("Bush Somerset Collection Bookcase",order.getProduct_name());
    }


}

