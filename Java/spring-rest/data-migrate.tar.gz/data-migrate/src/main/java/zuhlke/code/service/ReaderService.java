package zuhlke.code.service;

import zuhlke.code.model.StoreOrder;

import java.io.File;
import java.util.List;

public interface ReaderService {

    List<StoreOrder> read(File file);
}
