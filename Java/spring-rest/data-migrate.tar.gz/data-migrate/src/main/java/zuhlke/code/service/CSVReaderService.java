package zuhlke.code.service;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import zuhlke.code.model.StoreOrder;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@Slf4j
@Data
public class CSVReaderService implements ReaderService {



//    private File file;
//
//
//    public CSVReaderService(File file) {
//        this.file = file;
//    }

    public List<StoreOrder> read(File file){
        List<StoreOrder> result = new LinkedList<>();
        try (
                Reader reader = Files.newBufferedReader(file.toPath());
        ) {

            CsvToBean<StoreOrder> csvToBean = new CsvToBeanBuilder(reader)
                    .withType(StoreOrder.class)
                    .withIgnoreLeadingWhiteSpace(false)
                    .build();


            Iterator<StoreOrder> csvUserIterator = csvToBean.iterator();

            while (csvUserIterator.hasNext()) {
                StoreOrder order = csvUserIterator.next();
                log.info(order.toString());
                result.add(order);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }

}
