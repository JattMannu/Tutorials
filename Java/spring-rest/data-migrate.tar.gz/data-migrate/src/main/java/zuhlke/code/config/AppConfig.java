package zuhlke.code.config;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import zuhlke.code.service.CSVReaderService;
import zuhlke.code.service.ReaderService;

@Configuration
public class AppConfig
{
    @Bean
    public ReaderService argsComponent(@Value("${file.path}") String filePath) {
        // Example on how we can load different type of Reader .
        switch (FilenameUtils.getExtension(filePath)) {
            case "csv":
            default:
                return new CSVReaderService();
        }
    }
}
