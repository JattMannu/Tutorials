package zuhlke.code.converter;

import com.opencsv.bean.AbstractBeanField;
import com.opencsv.exceptions.CsvConstraintViolationException;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DateConverter <T> extends AbstractBeanField<T> {
    @Override
    protected Date convert(String s) throws CsvConstraintViolationException {
        try {
            List<Integer> collect = Arrays.stream(s.split("\\.")).map(s1 -> Integer.parseInt(s1)).collect(Collectors.toList());
            if(collect.size() == 3)
                return new Date(collect.get(2)+100,collect.get(1), collect.get(0));
        }catch (NumberFormatException  nfe){
            return null;
        }
        throw new CsvConstraintViolationException();
    }
}
