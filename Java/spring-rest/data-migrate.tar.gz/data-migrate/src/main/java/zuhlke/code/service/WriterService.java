package zuhlke.code.service;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import zuhlke.code.model.StoreOrder;

@Service
public interface WriterService extends CrudRepository<StoreOrder,Integer>{


}