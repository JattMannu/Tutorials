package zuhlke.code;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import zuhlke.code.runner.ApplicationStartupRunner;

@Slf4j
@SpringBootApplication
public class DatabaseMigrateApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatabaseMigrateApplication.class, args);
    }

    @Bean
    @Profile("test")
    public ApplicationRunner testRun() {
        return args -> log.info("TEST MODE");
    }

    @Bean
    public ApplicationRunner run() {
        return new ApplicationStartupRunner();
    }
}

