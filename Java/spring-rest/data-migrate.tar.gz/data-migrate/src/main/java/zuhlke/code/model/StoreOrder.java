package zuhlke.code.model;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvCustomBindByName;
import com.opencsv.bean.CsvDate;
import lombok.*;
import zuhlke.code.converter.DateConverter;

import javax.persistence.*;
import java.sql.Date;

@Builder
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class StoreOrder {

    //@CsvBindByName(column = "Row ID")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @CsvBindByName(column = "Order ID")
    @Column(columnDefinition = "VARCHAR(20)",unique = true,nullable = false)
    private String order_id;

    @CsvCustomBindByName(column = "Order Date", converter = DateConverter.class)
    @Column(nullable = false)
    private Date order_date;

    @CsvCustomBindByName(column = "Ship Date", converter = DateConverter.class)
    @Column(nullable = false)
    private Date ship_date;

    @CsvBindByName(column = "Ship Mode")
    @Column(columnDefinition = "VARCHAR(20)")
    private String ship_mode;

    @CsvBindByName(column = "Quantity")
    @Column(nullable = false)
    private Integer quantity;

    @CsvBindByName(column = "Discount")
    @Column(columnDefinition = "DECIMAL(3,2)")
    private Double discount;

    @CsvBindByName(column = "Profit")
    @Column(columnDefinition = "DECIMAL(6,2)", nullable = false)
    private Double profit;

    @CsvBindByName(column = "Product ID")
    @Column(columnDefinition = "VARCHAR(20)", unique = true, nullable = false)
    private String product_id;

    @CsvBindByName(column = "Customer Name")
    @Column(columnDefinition = "VARCHAR(255)", nullable = false)
    private String customer_name;

    @CsvBindByName(column = "Category")
    @Column(columnDefinition = "VARCHAR(255)", nullable = false)
    private String category;

    @CsvBindByName(column = "Customer ID")
    @Column(columnDefinition = "VARCHAR(20)", nullable = false,unique = true)
    private String customer_id;

    @CsvBindByName(column = "Product Name")
    @Column(columnDefinition = "VARCHAR(255)")
    private String product_name;

}
