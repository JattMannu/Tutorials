package zuhlke.code.runner;

import lombok.extern.slf4j.Slf4j;
import org.hibernate.PropertyValueException;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.dao.DataIntegrityViolationException;
import zuhlke.code.model.StoreOrder;
import zuhlke.code.service.ReaderService;
import zuhlke.code.service.WriterService;

import javax.persistence.EntityManagerFactory;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class ApplicationStartupRunner  implements ApplicationRunner {

    @Autowired
    WriterService writerService;

    @Autowired
    ReaderService readerService;

    @Value("${file.path: classpath:csv/sales.csv}")
    private File file;

    @Autowired
    EntityManagerFactory entityManagerFactory;

    @Override
    public void run(ApplicationArguments args) {
        List<StoreOrder> read = readerService.read(file);
        Map<StoreOrder, String> failToSave = new HashMap<>();
        read.forEach(storeOrder -> {
            try {
                writerService.save(storeOrder);
            } catch (ConstraintViolationException e) {
                failToSave.put(storeOrder, e.getCause().getCause().getMessage());
            } catch (DataIntegrityViolationException e) {
                if (e.getCause() instanceof ConstraintViolationException)
                    failToSave.put(storeOrder, e.getCause().getCause().getMessage());
                else if (e.getCause() instanceof PropertyValueException)
                    failToSave.put(storeOrder, e.getCause().getMessage());
                else
                    failToSave.put(storeOrder, e.getMessage());
            } catch (Exception e) {
                failToSave.put(storeOrder, e.getMessage());
            }

        });
        log.error("==================================================================================================");
        failToSave.forEach((storeOrder, e) ->
                log.error("{} : {} ", e, storeOrder));
        log.error("==================================================================================================");
    }
}
