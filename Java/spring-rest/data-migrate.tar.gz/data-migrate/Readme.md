#### Setup Local Development Environment 
 - Java11 ```openjdk 11.0.4 2019-07-16```
 - Maven ```Apache Maven 3.6.0```
 - MariaDB ```ariadb  Ver 15.1 Distrib 10.1.43-MariaDB, for debian-linux-gnu (x86_64) using readline 5.2```

Default Input file location : ```database-migrate/src/main/resources/csv/sales.csv```

set via application.yml
```
file:
  path: csv/sales.csv
 ```

Locally hosted MariaDB is called ```store```
set via application.yml
```
spring:
  datasource:
    url: jdbc:mysql://localhost/store
    username: admin
    driver-class-name: com.mysql.jdbc.Driver
 ```



#### Execution Command

```
mvn spring-boot:run -Dspring-boot.run.arguments=--file.path=<filepath>
```
 

#### Design Details

##### ReaderService
Since there is only only one writer in the current system. I have injected that CSVReaderService bean.
We can easily add more ```zuhlke.code.service.ReaderService``` by adding implementing a new class. This is following the OPEN-CLOSE princple.
By handling which ```zuhlke.code.service.ReaderService``` to load via ```zuhlke.code.config.AppConfig``` using file's extension.
I am assuming the default to be ```zuhlke.code.service.CSVReaderService```.

##### WriterService
Similar to the ```zuhlke.code.service.ReaderService``` we are using  ```zuhlke.code.service.WriterService```.
Conceptually they are  same, but the difference is that we have decided to use springframework's ```org.springframework.data.repository.CrudRepository```.
Rather then making our own. We have also shown a working example how we can point the system to another database. For the ```testing``` profile
we have used the H2 Database Engine. This is a simple in-memory database that we use for achieving our testing objective.
We can easily clean the database and create new record and validate them. The test for the WriterService is place ```zuhlke.code.WriterServiceTest```
here. 

##### Error Report
The ```zuhlke.code.model.StoreOrder``` that were not able to insert into the database are stored in the a error map and displayed
in the console for user to view. We can create a ```ReportService``` similar to ```ReaderService```
and ```WriterService``` were we can export the error into the different type. Examples like HTML report, Json Report , CSV Report

##### Integrated Model and Schema.
We decided to integrate the SQL schema into the Model. Having that intergated makes the ```zuhlke.code.model.StoreOrder``` the "golden" reference for anyone
to understand how the data is stored. This also ensure that any change in the schema will result in change in 
```zuhlke.code.model.StoreOrder``` class. However, this does tie our hands into the springframework.